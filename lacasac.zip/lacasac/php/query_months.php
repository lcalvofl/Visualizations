<?php
$servername = "173.249.157.155";
$username = "root";
$password = "chanclo123";
$dbname = "test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//Inicializamos las variables
$result = "";
$emparray = array();

// Recogemos el tipo de consulta 
$anyo = $_POST['anyo'];
// Recogemos clausula del archivo
$mes = $_POST['mes'];
/*$id = doubleval($_POST['id']);*/


/*$sql = "SELECT dia,tempIndoorC,tempOutdoorC from dias where FECHA ='".$id."'";*/
$sql = "select FECHA,ct1WattsHsInstant,ct2WattsHsInstant from dias where MES=".$mes." and left(FECHA,4)='".$anyo."'";



$result = $conn->query($sql);


if ($result->num_rows > 0) {
    // output data of each row
    $emparray = array();
    while($row = $result->fetch_assoc()) {
       $emparray[] = $row;
    }
    
    echo json_encode($emparray);
    
} else {
    echo "0 results";
}


$conn->close();
?>