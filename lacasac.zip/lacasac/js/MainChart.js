/* ***************** Grafo principal *************** */
//Grafo original obtenido de:
//http://bl.ocks.org/mbostock/7555321	

function MainChart(id, data, options,anyo) {
    
    var todo = data;
    
	var cfg = {
	 w: 400,				//Ancho grafo 
	 h: 400,				//Altura grafo
	 margin: {top: 20, right: 20, bottom: 20, left: 20}, //Margenes grafo
	 levels: 3,				//Niveles de descripción
	 maxValue: 0, 			//valor máximo ejes
	 labelFactor: 1.25, 	//Distancia labels 
	 wrapWidth: 60, 		//Espaciado labels o etiquetas
	 opacityArea: 0.35, 	//Opacidad areas
	 dotRadius: 4, 			//Circulo de dia
	 opacityCircles: 0.075, 	//Opacidad circulos dia
	 strokeWidth: 2, 		//Linea area
	 roundStrokes: false,	//Lineas
	 color: d3.scale.category10(), //Función color
     colorPunto: d3.scale.category10() //Función color gradiente valores puntos dia
     
	};
	
	//Cargamos valores en variables auxiliar
	if('undefined' !== typeof options){
	  for(var i in options){
		if('undefined' !== typeof options[i]){ cfg[i] = options[i]; }
	  }//for i
	}//if
	
	//Inicializamos valor máximo de los grafos
	var maxValue = 750;
		
	var allAxis = (data[0].map(function(i, j){return i.axis})),	//Nombre ejes
		total = allAxis.length,					//Número de ejes
		radius = Math.min(cfg.w/2, cfg.h/2), 	//Radios
		Format = d3.format('.2r'),			 	//Formateo labeling
		angleSlice = Math.PI * 2 / total;		//Ángulo radios
	
	//Escalado radios
	var rScale = d3.scale.linear()
		.range([0, radius])
		.domain([0, maxValue]);
		
	/////////////////////////////////////////////////////////
	//////////// Create the container SVG and g /////////////
	/////////////////////////////////////////////////////////

	//Limpiamos grafos anteriores al recargar pantalla
	d3.select(id).select("svg").remove();
	
	
	var svg = d3.select(id).append("svg")
			.attr("width",  cfg.w + cfg.margin.left + cfg.margin.right)
			.attr("height", cfg.h + cfg.margin.top + cfg.margin.bottom)
			.attr("class", "radar"+id);
			
	var g = svg.append("g")
			.attr("transform", "translate(" + (cfg.w/2 + cfg.margin.left) + "," + (cfg.h/2 + cfg.margin.top) + ")");
	
	
	//Efectos neón(blur) en grafos
	
	var filter = g.append('defs').append('filter').attr('id','glow'),
		feGaussianBlur = filter.append('feGaussianBlur').attr('stdDeviation','2.5').attr('result','coloredBlur'),
		feMerge = filter.append('feMerge'),
		feMergeNode_1 = feMerge.append('feMergeNode').attr('in','coloredBlur'),
		feMergeNode_2 = feMerge.append('feMergeNode').attr('in','SourceGraphic');

	//Grid circular
	
	//Definimos ejes
	var axisGrid = g.append("g").attr("class", "axisWrapper");  
    
	//Definimos background ejes circulares
	axisGrid.selectAll(".levels")
	   .data(d3.range(1,(cfg.levels+1)).reverse())
	   .enter()
		.append("circle")
		.attr("class", "gridCircle")
		.attr("r", function(d, i){return radius/cfg.levels*d;})
		.style("fill", "#416d87") 
		.style("stroke", "#416d87")
    .style("stroke-opacity", 0.15)
		.style("fill-opacity", 0.05) 
		.style("filter" , "url(#glow)");

	//Números que muestran el %
	axisGrid.selectAll(".axisLabel")
	   .data(d3.range(1,(cfg.levels+1)).reverse())
	   .enter().append("text")
	   .attr("class", "axisLabel")
	   .attr("x", 4)
	   .attr("y", function(d){return -d*radius/cfg.levels;})
	   .attr("dy", "0.4em")
	   .style("font-size", "8px")
	   .text(function(d,i) { return Format(maxValue * d/cfg.levels); }).attr("fill","#fff");

	//Dibujamos ejes
	
	//Radios
	var axis = axisGrid.selectAll(".axis")
		.data(allAxis)
		.enter()
		.append("g")
		.attr("class", "axis");
	
	axis.append("line")
		.attr("x1", 0)
		.attr("y1", 0)
		.attr("x2", function(d, i){ return rScale(maxValue*1.1) * Math.cos(angleSlice*i - Math.PI/2); })
		.attr("y2", function(d, i){ return rScale(maxValue*1.1) * Math.sin(angleSlice*i - Math.PI/2); })
		.attr("class", "line")
		.style("stroke", "#416d87")
        .style("stroke-opacity",0.25)
		.style("stroke-width", "2px"); 
var meses= ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
	//Modelamos transformación y selección de leyendas: 1 de cada mes a -> mes
	axis.append("text")
		.attr("class", "legend")
        .attr("id", "cotas")
		.style("font-size", "15px")
		.attr("text-anchor", "middle")
		.attr("dy", "0.25em")
        .attr("fill","#416d87")
		.attr("x", function(d, i){ return rScale(maxValue * cfg.labelFactor) * Math.cos(angleSlice*i - Math.PI/2); })
		.attr("y", function(d, i){ return rScale(maxValue * cfg.labelFactor) * Math.sin(angleSlice*i - Math.PI/2); })
		.text(function(d,i){
              
                if(d.substr(8,9)=="01") {  return meses[parseInt(d.substr(5,6))-1];
                }else{
                return "";   
                }
        
        })
		.call(wrap, cfg.wrapWidth);
    
    //Anulamos los no visibles
    d3.selectAll("#cotas")
    .style("opacity",function(d,i)  {
   
        
    if(d.substr(8,9)=="01") {

     return 1;
    }else{
     return 0;   
    }
    
    }  );

	//Areas funciones (Energia consumida vs. generada)
	
	var radarLine = d3.svg.line.radial()
		.interpolate("linear-closed")
		.radius(function(d) { return rScale(d.value); })
		.angle(function(d,i) {	return i*angleSlice; });
		
	if(cfg.roundStrokes) {
		radarLine.interpolate("cardinal-closed");
	}
					
	var blobWrapper = g.selectAll(".radarWrapper")
		.data(data)
		.enter().append("g")
		.attr("class", "radarWrapper");
			
	blobWrapper
		.append("path")
		.attr("class", "radarArea")
		.attr("d", function(d,i) { return radarLine(d); })
		.style("fill", function(d,i) { return cfg.color(i); })
		.style("fill-opacity", cfg.opacityArea)
		.on('mouseover', function (d,i){
			d3.selectAll(".radarArea")
				.transition().duration(200)
				.style("fill-opacity", 0.1); 
			d3.select(this)
				.transition().duration(200)
				.style("fill-opacity", 0.7);	
		})
		.on('mouseout', function(){
			d3.selectAll(".radarArea")
				.transition().duration(200)
				.style("fill-opacity", cfg.opacityArea);
		});
		
	blobWrapper.append("path")
		.attr("class", "radarStroke")
		.attr("d", function(d,i) { return radarLine(d); })
		.style("stroke-width", cfg.strokeWidth + "px")
		.style("stroke", function(d,i) { return cfg.color(i); })
		.style("fill", "none")
		.style("filter" , "url(#glow)");		
	
	blobWrapper.selectAll(".radarCircle")
		.data(function(d,i) { return d; }) 
		.enter().append("circle")
		.attr("class", "radarCircle")
		.style("fill", function(d,i,j) { return cfg.color(j); })
		.style("fill-opacity", 0.8);

	
    
    //Mostrar leyendas hover
	var blobCircleWrapper = g.selectAll(".radarCircleWrapper")
		.data(data)
		.enter().append("g")
		.attr("class", "radarCircleWrapper");
		
	//Circulos de interacción
	blobCircleWrapper.selectAll(".radarInvisibleCircle")
		.data(function(d,i) { return d; })
		.enter().append("circle")
		.attr("class", "radarInvisibleCircle")
		.attr("r", 3) //Radio circulos
		.attr("cx", function(d,i){ return rScale(d.value) * Math.cos(angleSlice*i - Math.PI/2); })
		.attr("cy", function(d,i){ return rScale(d.value) * Math.sin(angleSlice*i - Math.PI/2); })
		.style("fill", "fff")
        .style("fill-opacity",0.5)
		.style("pointer-events", "all")
		.on("mouseover", function(d,i) {
			newX =  parseFloat(d3.select(this).attr('cx')) - 10;
			newY =  parseFloat(d3.select(this).attr('cy')) - 10;
					
			tooltip
				.attr('x', newX)
				.attr('y', newY)
				.text(Format(d.value)+"KW/h")
                .style('font-size','1em')
                .style('fill','#fff')
				.transition().duration(200)
				.style('opacity', 1);
        
            d3.select(this).transition().duration(750).attr("r",10).style('fill-opacity', 0.5).style('stroke-opacity',1);
		})
		.on("mouseout", function(){
			tooltip.transition().duration(200)
				.style("opacity", 0);
                d3.select(this).transition().duration(750).attr("r",3);
		})
        .on('click',function(j){ 
           //alert(j.axis);
           dibuja_auxiliares(j.axis);
        
        });
    
    

    function filterCriteria(d) {
       return d.axis === 5.11;
    }
    
    
    
    //Dibujamos gráficas auxiliares mediante llamada a BBDD. PHP
    function dibuja_auxiliares(filtro,dia_semana){
        
        d3.selectAll("path.line").remove();
        d3.selectAll(".piu").remove();
       
         $.post('php/query2.php', { id: filtro , consulta:1  }, function(data) {  /* 2014-10-23 */
        //Grafo temperaturas
        dibuja_temperaturas_1(data,1,"temp");
        });
            
         $.post('php/query2.php', { id: filtro , consulta:2  }, function(data) {  /* 2014-10-23 */
        //Grafo humedad
        dibuja_temperaturas_1(data,2,"hum");
        });
        
         $.post('php/query2.php', { id: filtro , consulta:3  }, function(data) {  /* 2014-10-23 */
        //Grafo luminosidad
        dibuja_temperaturas_1(data,3,"bright");
        });
        
         $.post('php/query2.php', { id: "Monday" , consulta:5  }, function(data) {  /* 2014-10-23 */
        //Grafo consumo medio dia de la semana seleccionado 
        dibuja_temperaturas_1(data,4,"energy");
        });
        
         $.post('php/query2.php', { id: filtro , consulta:4 }, function(data) {  /* 2014-10-23 */
        //Consumo del dia particular
        dibuja_temperaturas_1(data,4,"otro");
        });
    
    }   
    
    var tooltip = g.append("text")
		.attr("class", "tooltip")
		.style("opacity", 0);
	
	
	
	
	function wrap(text, width) {
	  text.each(function() {
		var text = d3.select(this),
			words = text.text().split(/\s+/).reverse(),
			word,
			line = [],
			lineNumber = 0,
			lineHeight = 1.4, 
			y = text.attr("y"),
			x = text.attr("x"),
			dy = parseFloat(text.attr("dy")),
			tspan = text.text(null).append("tspan").attr("x", x).attr("y", y).attr("dy", dy + "em");
			
		while (word = words.pop()) {
		  line.push(word);
		  tspan.text(line.join(" "));
		  if (tspan.node().getComputedTextLength() > width) {
			line.pop();
			tspan.text(line.join(" "));
			line = [word];
			tspan = text.append("tspan").attr("x", x).attr("y", y).attr("dy", ++lineNumber * lineHeight + dy + "em").text(word);
		  }
		}
	  });
	}
	
}