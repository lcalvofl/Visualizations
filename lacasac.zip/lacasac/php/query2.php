<?php
$servername = "173.249.157.155";
$username = "root";
$password = "chanclo123";
$dbname = "test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//Inicializamos las variables
$result = "";
$emparray = array();

// Recogemos el tipo de consulta 
$consulta=$_POST['consulta'];
// Recogemos clausula del archivo
$id = $_POST['id'];
/*$id = doubleval($_POST['id']);*/

if($consulta==1){
$sql = "SELECT HORA,tempIndoorC AS tempInterior,tempOutdoorC AS tempExterior from horas where FECHA ='".$id."'";
}else if($consulta == 2){
$sql = "SELECT HORA,temphumOutdoor AS humedadExterior,SShumidity AS humedadINTERIOR from horas where FECHA ='".$id."'";
}else if($consulta == 3){
$sql = "SELECT HORA,techoLightLevel AS luzExterior,SSlightLevel AS luzInterior from horas where FECHA ='".$id."'";
}else if($consulta == 4){
$sql = "SELECT HORA,ct1WattsHsInstant as Consumo from horas where FECHA ='".$id."'";
}else{
$sql = "SELECT HORA,avg(ct1WattsHsInstant) as MediaConsumo from horas where DIA_SEMANA='Monday' group by HORA";
}


$result = $conn->query($sql);


if ($result->num_rows > 0) {
    // output data of each row
    $emparray = array();
    while($row = $result->fetch_assoc()) {
       $emparray[] = $row;
    }
    
    echo json_encode($emparray);
    
} else {
    echo "0 results";
}




$conn->close();
?>