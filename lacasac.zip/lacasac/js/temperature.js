//Cod. original de
//https://code.tutsplus.com/tutorials/building-a-multi-line-chart-using-d3js--cms-22935


function dibuja_temperaturas_1(myData,codigo,tipo) {
 
//Recogemos datos   
var data = JSON.parse(myData); 
    
//Establecer márgenes                   
var margin = {top: 60, right: 80, bottom: 60, left: 80},
    width = 550 - margin.left - margin.right,
    height = 220 - margin.top - margin.bottom;

//Definir escala
var x = d3.scale.linear()
    .range([0, width])
	.domain([0,23]);

//Ejes dependiendo del tipo de gráfica
//Temperaturas
if(tipo=="temp"){
    maxValue=50;
    var color = d3.scale.ordinal()
	.range(["#fff", "#fff"])    
	.domain(["tempIndoorC","tempOutdoorC"]);
//Humedades relativas
}else if(tipo=="hum"){
    maxValue=100;
    var color = d3.scale.ordinal()
	.range(["#fff", "#fff"])     
	.domain(["tempIndoorC","tempOutdoorC"]);
//Iluminación ambiental interior y exterior    
}else if(tipo=="bright"){
    maxValue=5;
    var color = d3.scale.ordinal()
	.range(["#fff", "#fff"])   
	.domain(["tempIndoorC","tempOutdoorC"]);
//Consumo medio    
}else if(tipo=="energy"){
    maxValue=700;
    var color = d3.scale.ordinal()
	.range(["#ef7aeb", "#fff"])     
	.domain(["tempIndoorC","tempOutdoorC"]);
//Consumo actual dia   
}else{
    maxValue=700;
    var color = d3.scale.ordinal()
	.range(["#fff", "#ef7aeb"])     
	.domain(["tempIndoorC","tempOutdoorC"]);
}


//var y = d3.scale.linear()
    .range([height, 0])
	.domain([0,maxValue]);


//Aspecto ejes    
var color_cool = d3.scale.linear()      
    .range(["#9c6ba8","#bb95b2"])
    .domain([0,50]);
    
var xAxis = d3.svg.axis()
    .scale(x)
    .orient("bottom")
	.tickFormat(d3.format("d"));

var yAxis = d3.svg.axis()
    .scale(y)
    .orient("left")
	.ticks(5)
	.tickSize(-width, 0, 0);

var line = d3.svg.line()
    .interpolate("cardinal")
    .x(function(d) { return x(d.HORA); })
    .y(function(d) { return y(d.temperatura); });

//ubicar grafo en sección –Svg– correspondiente
var grafo ="";   
if (codigo == 1){
    grafo="#visualisation1";
}else if(codigo==2){
    grafo="#visualisation2";
}else if(codigo==3){
    grafo="#visualisation3";
}else{
    grafo="#visualisation4";
}

//Dibujar cada uno de los svg o secciones de gráfica
var svg = d3.select(grafo)
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");


  var keys = d3.keys(data[0]).filter(function(key) { return key !== "HORA"; });
  
  //Recoger y mostrar valores de cada una de las select
  var animalLines = keys.map(function(name) {
    return {
      
      name: name,
      values: data.map(function(d) {
          
  	        return {
  				HORA: d.HORA,
  				temperatura: d[name]};
        })
    };
  });                             

  //Ejes
  svg.append("g")
      .attr("class", "x axis")
      .attr("fill","#416d87")
      .attr("transform", "translate(0," + height + ")")
 
      .call(xAxis);

  svg.append("g")
      .attr("class", "y axis")
  .attr("fill","#416d87")
  
      .call(yAxis);

  
    //Lineas
  	var lines = svg.selectAll(".lines")
      	.data(animalLines)
    	.enter()
        .append("g")
      	.attr("class", "lines");


	lines.append("path")
        .transition()
        .duration(2000)
		.attr("class", "line")
		.attr("d", function(d) { return line(d.values); })
		.style("stroke", function(d) { return color(d.name); })
		.style("stroke-width", 14)
		.style("opacity", 0.05);
		
	lines.append("path")
      	.attr("class", "line")
      	.attr("d", function(d) { return line(d.values); })
      	.style("stroke", function(d) { return color(d.name); })
		.style("stroke-width", 8)
		.style("opacity", 0.1);
				
	lines.append("path")
	      	.attr("class", "line")
	      	.attr("d", function(d) { return line(d.values); })
	      	.style("stroke", function(d) { return color(d.name); })
			.style("stroke-width", 1.5);

//Etiquetas que acompañan al grafo
  	lines.append("text")
          .attr("class", "legend piu")
      	  .datum(function(d) { return {name: d.name, value: d.values[d.values.length - 1]}; })
      	  .attr("transform", function(d) { 
			  return "translate(" + x(d.value.HORA) + "," + y(d.value.temperatura) + ")"; 
		  })
      	  .attr("x", 3)
      	  .attr("dy", ".15em")
          .attr("fill","#416d87")
      	  .text(function(d) { return d.name; });
	  


    
}
